import java.util.*;

class Main {
  public static void main(String args[]){
  
      //initialize scanner and vars
      Scanner scan = new Scanner (System.in);
      String yesNoAnswer1; //answer to "do you know protein name"
      String loopCodon = ""; //recylable String that tests amino name in loop
      String incompleteSequence = "**Incomplete Codon**";
      ArrayList <String> sequenceOrder = new ArrayList <String>();


      //run
      System.out.println("Hello. Do you know the exact codon sequences?");
      yesNoAnswer1 = scan.nextLine();

      //if input doesn't start w/ y we deny
      if (lowerCaseIt(yesNoAnswer1).charAt(0) != 'y'){
        System.out.println("Sorry, we can't help you.");
      }
      //if input does start with y 
      else{
        System.out.println("Okay, please enter the sequences.");
        String sequence = scan.nextLine();

        //testing for amino sequence names
        for (int i = 1; i <= sequence.length(); i++){
            if (i % 3 == 1)
              loopCodon = "";
            
            loopCodon += sequence.charAt(i-1);
            if (i % 3 == 0)
                sequenceOrder.add(identifyAmino(loopCodon));
            if (i==sequence.length() && sequence.length() % 3 != 0) {
              sequenceOrder.add(incompleteSequence);
            }
    

            

          }
      


        System.out.println ("Here is your sequence:");
        for(int y = 0; y < sequenceOrder.size(); y++){
          if (y != sequenceOrder.size()-1)
          System.out.print(sequenceOrder.get(y)+ ", ");
          else
          System.out.print(sequenceOrder.get(y));
        }


      }
      

  }

  //method lowercases strings
  public static String lowerCaseIt(String word){
    return word.toLowerCase();
  }

  //method classifies amino acid from codon sequence
  public static String identifyAmino (String codonOrder){
    String first = "";
    if (lowerCaseIt(codonOrder).equals("gcu") || lowerCaseIt(codonOrder).equals("gcc") || lowerCaseIt(codonOrder).equals("gca") || lowerCaseIt(codonOrder).equals("gcg"))
        first = "Alanine";
    else if (lowerCaseIt(codonOrder).equals("cgu") || lowerCaseIt(codonOrder).equals("cgc") || lowerCaseIt(codonOrder).equals("cga") || lowerCaseIt(codonOrder).equals("cgg") || lowerCaseIt(codonOrder).equals("aga") || lowerCaseIt(codonOrder).equals("agg"))
        first = "Arganine";
    else if (lowerCaseIt(codonOrder).equals("aau") || lowerCaseIt(codonOrder).equals("aac"))
        first = "Asparagine";
    else if (lowerCaseIt(codonOrder).equals("gau") || lowerCaseIt(codonOrder).equals("gac"))
        first = "Aspartic Acid";
    else if (lowerCaseIt(codonOrder).equals("ugu") || lowerCaseIt(codonOrder).equals("ugc"))
        first = "Cysteine";
    else if (lowerCaseIt(codonOrder).equals("caa") || lowerCaseIt(codonOrder).equals("cag"))
        first = "Glutamine";
    else if (lowerCaseIt(codonOrder).equals("gaa") || lowerCaseIt(codonOrder).equals("gag"))
        first = "Glutamic Acid";
    else if (lowerCaseIt(codonOrder).equals("ggu") || lowerCaseIt(codonOrder).equals("ggc") || lowerCaseIt(codonOrder).equals("gga") || lowerCaseIt(codonOrder).equals("ggg"))
        first = "Glycine";
    else if (lowerCaseIt(codonOrder).equals("cau") || lowerCaseIt(codonOrder).equals("cac"))
        first = "Histidine";
    else if (lowerCaseIt(codonOrder).equals("auu") || lowerCaseIt(codonOrder).equals("auc") || lowerCaseIt(codonOrder).equals("aua"))
        first = "Isoleucine";
    else if (lowerCaseIt(codonOrder).equals("cuu") || lowerCaseIt(codonOrder).equals("cuc") || lowerCaseIt(codonOrder).equals("cua") || lowerCaseIt(codonOrder).equals("cug") || lowerCaseIt(codonOrder).equals("uua") || lowerCaseIt(codonOrder).equals("uug"))
        first = "Leucine";        
    else if (lowerCaseIt(codonOrder).equals("aaa") || lowerCaseIt(codonOrder).equals("aag"))
        first = "Lysine";
    else if (lowerCaseIt(codonOrder).equals("aug"))
        first = "Methionine (Start)";
    else if (lowerCaseIt(codonOrder).equals("uuu") || lowerCaseIt(codonOrder).equals("uuc"))
        first = "Phenylalanine";
    else if (lowerCaseIt(codonOrder).equals("ccu") || lowerCaseIt(codonOrder).equals("ccc") || lowerCaseIt(codonOrder).equals("cca") || lowerCaseIt(codonOrder).equals("ccg"))
        first = "Proline";
    else if (lowerCaseIt(codonOrder).equals("ucu") || lowerCaseIt(codonOrder).equals("ucc") || lowerCaseIt(codonOrder).equals("uca") || lowerCaseIt(codonOrder).equals("ucg") || lowerCaseIt(codonOrder).equals("agu") || lowerCaseIt(codonOrder).equals("agc"))
        first = "Serine";
    else if (lowerCaseIt(codonOrder).equals("acu") || lowerCaseIt(codonOrder).equals("acc") || lowerCaseIt(codonOrder).equals("aca") || lowerCaseIt(codonOrder).equals("acg"))
        first = "Threonine";
    else if (lowerCaseIt(codonOrder).equals("ugg"))
        first = "Tryptophan";
    else if (lowerCaseIt(codonOrder).equals("uau") || lowerCaseIt(codonOrder).equals("uac"))
        first = "Tyrosine";
    else if (lowerCaseIt(codonOrder).equals("guu") || lowerCaseIt(codonOrder).equals("guc") || lowerCaseIt(codonOrder).equals("gua") || lowerCaseIt(codonOrder).equals("gug"))
        first = "Valine";
    else if (lowerCaseIt(codonOrder).equals("uaa") || lowerCaseIt(codonOrder).equals("uag") || lowerCaseIt(codonOrder).equals("uga"))
        first = "Stop";
    else 
      first = null;
    return first;
  }


}

/*public class Protein {
  private ArrayList sequenceOrder;
  private ArrayList polarOrder;

  public Protein (ArrayList o)




}*/