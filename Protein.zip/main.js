let input=document.getElementById(`input`);
let output=document.getElementById(`output`);

let Amino_Acids=[
  {
    name:`Alanine`,
    codons:[`gcu`,`gcc`,`gca`,`gcg`]
  },
  {
    name:`Arganine`,
    codons:[`cgu`,`cgc`,`cga`,`cgg`,`aga`,`agg`]
  },
  {
    name:`Asparagine`,
    codons:[`aau`,`aac`]
  },
  {
    name:`Aspartic_Acid`,
    codons:[`gau`,`gac`]
  },
  {
    name:`Cysteine`,
    codons:[`ugu`,`ugc`]
  },
  {
    name:`Glutamine`,
    codons:[`caa`,`cag`]
  },
  {
    name:`Glutamic_Acid`,
    codons:[`gaa`,`gag`]
  },
  {
    name:`Glycine`,
    codons:[`ggu`,`ggc`,`gga`,`ggg`]
  },
  {
    name:`Histidine`,
    codons:[`cau`,`cac`]
  },
  {
    name:`Isoleucine`,
    codons:[`auu`,`auc`,`aua`]
  },
  {
    name:`Leucine`,
    codons:[`cuu`,`cuc`,`cua`,`cug`,`uua`,`uug`]
  },
  {
    name:`Lysine`,
    codons:[`aaa`,`aag`]
  },
  {
    name:`Methionine`,
    codons:[`aug`],
    type:`START`
  },
  {
    name:`Phenylalanine`,
    codons:[`uuu`,`uuc`]
  },
  {
    name:`Proline`,
    codons:[`ccu`,`ccc`,`cca`,`ccg`]
  },
  {
    name:`Serine`,
    codons:[`ucu`,`ucc`,`uca`,`ucg`,`agu`,`agc`]
  },
  {
    name:`Threonine`,
    codons:[`acu`,`acc`,`aca`,`acg`]
  },
  {
    name:`Tryptophan`,
    codons:[`ugg`]
  },
  {
    name:`Tyrosine`,
    codons:[`uau`,`uac`]
  },
  {
    name:`Valine`,
    codons:[`guu`,`guc`,`gua`,`gug`]
  },
  {
    name:``,
    codons:[`uaa`,`uag`,`uga`],
    type=`STOP`
];

display.addEventListener(`keypress`,(event)=>{
  if(event.keyCode==13){
    let stringInput=display.value;
    let stringTemp;
    let stringArray=[];
    let stringOutput;

    let f=0;
    for(let i=0;i<stringInput.length;i++){
      stringTemp.concat(stringInput.charAt(i));
      if(f==3){
        stringArray.push(stringTemp);
        stringtemp=``;
      }
    }
    if(stringTemp.length<=3){
      console.log(`incomplete`);
      stringTemp=``;
    }
    for(let y=0;y<stringArray.length;y++){
      console.log(getCodon(stringArray[y]));
    }
  }
});

function getCodon(codon){
  for(let b=0;b<Amino_Acids.length;b++){
    for(let x=0;x<Amino_Acids[b].codons.length){
      if(Amino_Acids[b].codons[x]==codon){
        return(Amino_Acids[b].name);
      }
    }
  }
}